
"""
Educational Hub MCP - Main FastAPI Application
"""
import logging
from fastapi import FastAPI, Depends, HTTPException, status
from fastapi.security import HTTPBearer
from fastapi.middleware.cors import CORSMiddleware
from contextlib import asynccontextmanager
import uvicorn
import asyncio

from config.settings import settings
from auth.jwt_handler import JWTHandler
from database.connection import init_db
from mcp_hub import MCPHub
from api.routes import auth, users, modules, reports

# Configure logging
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s'
)
logger = logging.getLogger(__name__)

# Global MCP Hub instance
mcp_hub = None

@asynccontextmanager
async def lifespan(app: FastAPI):
    """Application lifespan management"""
    global mcp_hub
    
    # Startup
    logger.info("Starting Educational Hub MCP...")
    
    # Initialize database
    await init_db()
    
    # Initialize MCP Hub
    mcp_hub = MCPHub()
    await mcp_hub.start()
    
    # Store MCP hub in app state
    app.state.mcp_hub = mcp_hub
    
    logger.info("Educational Hub MCP started successfully")
    
    yield
    
    # Shutdown
    logger.info("Shutting down Educational Hub MCP...")
    if mcp_hub:
        await mcp_hub.stop()
    logger.info("Educational Hub MCP stopped")

# Create FastAPI application
app = FastAPI(
    title="Educational Hub MCP",
    description="Central hub for modular educational system using MCP",
    version="1.0.0",
    lifespan=lifespan
)

# Add CORS middleware
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# Security
security = HTTPBearer()
jwt_handler = JWTHandler()

# Include routers
app.include_router(auth.router, prefix="/api/auth", tags=["Authentication"])
app.include_router(users.router, prefix="/api/users", tags=["Users"])
app.include_router(modules.router, prefix="/api/modules", tags=["Modules"])
app.include_router(reports.router, prefix="/api/reports", tags=["Reports"])

@app.get("/")
async def root():
    """Root endpoint"""
    return {
        "message": "Educational Hub MCP API",
        "version": "1.0.0",
        "status": "running"
    }

@app.get("/health")
async def health_check():
    """Health check endpoint"""
    return {
        "status": "healthy",
        "mcp_hub_status": "running" if mcp_hub and mcp_hub.is_running else "stopped"
    }

if __name__ == "__main__":
    uvicorn.run(
        "main:app",
        host="0.0.0.0",
        port=5000,
        reload=True,
        log_level="info"
    )
