
"""
Database models for Educational Hub MCP
"""
from sqlalchemy import Column, Integer, String, DateTime, Boolean, Text, JSON, ForeignKey, Table
from sqlalchemy.orm import relationship
from sqlalchemy.sql import func
from database.connection import Base

# Association table for user roles (many-to-many)
user_roles = Table(
    'user_roles',
    Base.metadata,
    Column('user_id', Integer, ForeignKey('users.id'), primary_key=True),
    Column('role_id', Integer, ForeignKey('roles.id'), primary_key=True)
)

# Association table for role permissions (many-to-many)
role_permissions = Table(
    'role_permissions',
    Base.metadata,
    Column('role_id', Integer, ForeignKey('roles.id'), primary_key=True),
    Column('permission_id', Integer, ForeignKey('permissions.id'), primary_key=True)
)

class User(Base):
    """User model for students, teachers, and administrators"""
    __tablename__ = "users"
    
    id = Column(Integer, primary_key=True, index=True)
    email = Column(String, unique=True, index=True, nullable=False)
    username = Column(String, unique=True, index=True, nullable=False)
    hashed_password = Column(String, nullable=False)
    first_name = Column(String, nullable=False)
    last_name = Column(String, nullable=False)
    phone = Column(String, nullable=True)
    
    # User type: student, teacher, administrator
    user_type = Column(String, nullable=False, default="student")
    
    # Status
    is_active = Column(Boolean, default=True)
    is_verified = Column(Boolean, default=False)
    
    # Timestamps
    created_at = Column(DateTime(timezone=True), server_default=func.now())
    updated_at = Column(DateTime(timezone=True), onupdate=func.now())
    last_login = Column(DateTime(timezone=True), nullable=True)
    
    # Additional data
    profile_data = Column(JSON, default=dict)
    
    # Relationships
    roles = relationship("Role", secondary=user_roles, back_populates="users")
    
    def __repr__(self):
        return f"<User(id={self.id}, email='{self.email}', type='{self.user_type}')>"

class Role(Base):
    """Role model for user permissions"""
    __tablename__ = "roles"
    
    id = Column(Integer, primary_key=True, index=True)
    name = Column(String, unique=True, nullable=False)
    description = Column(Text, nullable=True)
    
    # Role scope: global, module-specific
    scope = Column(String, default="global")
    module_name = Column(String, nullable=True)
    
    # Status
    is_active = Column(Boolean, default=True)
    
    # Timestamps
    created_at = Column(DateTime(timezone=True), server_default=func.now())
    updated_at = Column(DateTime(timezone=True), onupdate=func.now())
    
    # Relationships
    users = relationship("User", secondary=user_roles, back_populates="roles")
    permissions = relationship("Permission", secondary=role_permissions, back_populates="roles")
    
    def __repr__(self):
        return f"<Role(id={self.id}, name='{self.name}')>"

class Permission(Base):
    """Permission model for granular access control"""
    __tablename__ = "permissions"
    
    id = Column(Integer, primary_key=True, index=True)
    name = Column(String, unique=True, nullable=False)
    description = Column(Text, nullable=True)
    
    # Permission details
    resource = Column(String, nullable=False)  # e.g., 'users', 'attendance', 'evaluations'
    action = Column(String, nullable=False)    # e.g., 'create', 'read', 'update', 'delete'
    
    # Scope
    scope = Column(String, default="global")
    conditions = Column(JSON, default=dict)
    
    # Status
    is_active = Column(Boolean, default=True)
    
    # Timestamps
    created_at = Column(DateTime(timezone=True), server_default=func.now())
    
    # Relationships
    roles = relationship("Role", secondary=role_permissions, back_populates="permissions")
    
    def __repr__(self):
        return f"<Permission(id={self.id}, name='{self.name}')>"

class Module(Base):
    """Module registration and configuration"""
    __tablename__ = "modules"
    
    id = Column(Integer, primary_key=True, index=True)
    name = Column(String, unique=True, nullable=False)
    display_name = Column(String, nullable=False)
    description = Column(Text, nullable=True)
    
    # Module details
    module_type = Column(String, nullable=False)  # attendance, evaluation, communication, etc.
    version = Column(String, nullable=False)
    
    # Connection details
    base_url = Column(String, nullable=True)
    mcp_endpoint = Column(String, nullable=True)
    api_key = Column(String, nullable=True)
    
    # Configuration
    config = Column(JSON, default=dict)
    capabilities = Column(JSON, default=list)
    
    # Status
    is_active = Column(Boolean, default=True)
    is_connected = Column(Boolean, default=False)
    
    # Timestamps
    created_at = Column(DateTime(timezone=True), server_default=func.now())
    updated_at = Column(DateTime(timezone=True), onupdate=func.now())
    last_ping = Column(DateTime(timezone=True), nullable=True)
    
    # Relationships
    connections = relationship("ModuleConnection", back_populates="module")
    
    def __repr__(self):
        return f"<Module(id={self.id}, name='{self.name}', type='{self.module_type}')>"

class ModuleConnection(Base):
    """Module connection and sync status"""
    __tablename__ = "module_connections"
    
    id = Column(Integer, primary_key=True, index=True)
    module_id = Column(Integer, ForeignKey("modules.id"), nullable=False)
    
    # Connection details
    connection_type = Column(String, nullable=False)  # mcp, rest_api, webhook
    endpoint = Column(String, nullable=False)
    status = Column(String, default="disconnected")  # connected, disconnected, error
    
    # Sync information
    last_sync = Column(DateTime(timezone=True), nullable=True)
    sync_status = Column(String, default="pending")  # success, failed, pending
    sync_data = Column(JSON, default=dict)
    
    # Error tracking
    error_count = Column(Integer, default=0)
    last_error = Column(Text, nullable=True)
    
    # Timestamps
    created_at = Column(DateTime(timezone=True), server_default=func.now())
    updated_at = Column(DateTime(timezone=True), onupdate=func.now())
    
    # Relationships
    module = relationship("Module", back_populates="connections")
    
    def __repr__(self):
        return f"<ModuleConnection(id={self.id}, module_id={self.module_id}, status='{self.status}')>"

class Student(Base):
    """Extended student information"""
    __tablename__ = "students"
    
    id = Column(Integer, primary_key=True, index=True)
    user_id = Column(Integer, ForeignKey("users.id"), unique=True, nullable=False)
    
    # Student specific information
    student_id = Column(String, unique=True, nullable=False)
    enrollment_date = Column(DateTime(timezone=True), nullable=False)
    grade_level = Column(String, nullable=True)
    section = Column(String, nullable=True)
    
    # Academic information
    academic_year = Column(String, nullable=True)
    status = Column(String, default="active")  # active, inactive, graduated, transferred
    
    # Additional data
    emergency_contact = Column(JSON, default=dict)
    medical_info = Column(JSON, default=dict)
    academic_record = Column(JSON, default=dict)
    
    # Timestamps
    created_at = Column(DateTime(timezone=True), server_default=func.now())
    updated_at = Column(DateTime(timezone=True), onupdate=func.now())
    
    # Relationships
    user = relationship("User", foreign_keys=[user_id])
    
    def __repr__(self):
        return f"<Student(id={self.id}, student_id='{self.student_id}')>"

class Teacher(Base):
    """Extended teacher information"""
    __tablename__ = "teachers"
    
    id = Column(Integer, primary_key=True, index=True)
    user_id = Column(Integer, ForeignKey("users.id"), unique=True, nullable=False)
    
    # Teacher specific information
    employee_id = Column(String, unique=True, nullable=False)
    hire_date = Column(DateTime(timezone=True), nullable=False)
    department = Column(String, nullable=True)
    
    # Professional information
    qualification = Column(String, nullable=True)
    specialization = Column(JSON, default=list)
    subjects = Column(JSON, default=list)
    
    # Status
    employment_status = Column(String, default="active")  # active, inactive, terminated
    
    # Additional data
    professional_development = Column(JSON, default=list)
    performance_data = Column(JSON, default=dict)
    
    # Timestamps
    created_at = Column(DateTime(timezone=True), server_default=func.now())
    updated_at = Column(DateTime(timezone=True), onupdate=func.now())
    
    # Relationships
    user = relationship("User", foreign_keys=[user_id])
    
    def __repr__(self):
        return f"<Teacher(id={self.id}, employee_id='{self.employee_id}')>"
