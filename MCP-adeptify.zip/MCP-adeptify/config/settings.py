
"""
Configuration settings for Educational Hub MCP
"""
import os
from typing import Optional
from pydantic_settings import BaseSettings

class Settings(BaseSettings):
    """Application settings"""
    
    # Application
    APP_NAME: str = "Educational Hub MCP"
    APP_VERSION: str = "1.0.0"
    DEBUG: bool = False
    ENVIRONMENT: str = "production"
    
    # Database
    DATABASE_URL: str = "postgresql://user:password@localhost:5432/educational_hub"
    DATABASE_ECHO: bool = False
    
    # JWT
    JWT_SECRET_KEY: str = "your-secret-key-here-change-in-production"
    JWT_ALGORITHM: str = "HS256"
    JWT_ACCESS_TOKEN_EXPIRE_MINUTES: int = 30
    JWT_REFRESH_TOKEN_EXPIRE_DAYS: int = 7
    
    # Redis (optional)
    REDIS_URL: Optional[str] = None
    
    # MCP
    MCP_PORT: int = 8765
    MCP_HOST: str = "0.0.0.0"
    
    # Security
    BCRYPT_ROUNDS: int = 12
    
    # Logging
    LOG_LEVEL: str = "INFO"
    
    # CORS
    CORS_ORIGINS: list = ["*"]
    
    # Module Configuration
    ATTENDANCE_MODULE_URL: Optional[str] = None
    EVALUATION_MODULE_URL: Optional[str] = None
    COMMUNICATION_MODULE_URL: Optional[str] = None
    
    class Config:
        env_file = ".env"
        case_sensitive = True

# Create settings instance
settings = Settings()
