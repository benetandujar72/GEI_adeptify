
"""
User management routes for Educational Hub MCP
"""
from fastapi import APIRouter, Depends, HTTPException, status, Query
from fastapi.security import HTTPBearer
from sqlalchemy.ext.asyncio import AsyncSession
from sqlalchemy import select, func
from pydantic import BaseModel, EmailStr
from typing import Optional, List
from datetime import datetime

from database.connection import get_db
from database.models import User, Role, Student, Teacher
from auth.jwt_handler import JWTHandler

router = APIRouter()
security = HTTPBearer()
jwt_handler = JWTHandler()

class UserUpdate(BaseModel):
    first_name: Optional[str] = None
    last_name: Optional[str] = None
    phone: Optional[str] = None
    is_active: Optional[bool] = None

class StudentCreate(BaseModel):
    user_id: int
    student_id: str
    enrollment_date: datetime
    grade_level: Optional[str] = None
    section: Optional[str] = None
    academic_year: Optional[str] = None

class TeacherCreate(BaseModel):
    user_id: int
    employee_id: str
    hire_date: datetime
    department: Optional[str] = None
    qualification: Optional[str] = None
    subjects: Optional[List[str]] = None

async def get_current_user(
    token: str = Depends(security),
    db: AsyncSession = Depends(get_db)
):
    """Get current user from token"""
    user_info = jwt_handler.get_user_from_token(token.credentials)
    user_id = int(user_info["user_id"])
    
    stmt = select(User).where(User.id == user_id)
    result = await db.execute(stmt)
    user = result.scalar_one_or_none()
    
    if not user:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail="User not found"
        )
    
    return user

@router.get("/")
async def get_users(
    skip: int = Query(0, ge=0),
    limit: int = Query(10, ge=1, le=100),
    user_type: Optional[str] = Query(None),
    search: Optional[str] = Query(None),
    current_user: User = Depends(get_current_user),
    db: AsyncSession = Depends(get_db)
):
    """Get users with pagination and filtering"""
    
    # Check permissions (only admin can view all users)
    if current_user.user_type != "administrator":
        raise HTTPException(
            status_code=status.HTTP_403_FORBIDDEN,
            detail="Not enough permissions"
        )
    
    # Build query
    stmt = select(User)
    
    if user_type:
        stmt = stmt.where(User.user_type == user_type)
    
    if search:
        search_term = f"%{search}%"
        stmt = stmt.where(
            (User.first_name.ilike(search_term)) |
            (User.last_name.ilike(search_term)) |
            (User.email.ilike(search_term)) |
            (User.username.ilike(search_term))
        )
    
    # Get total count
    count_stmt = select(func.count()).select_from(stmt.subquery())
    total_result = await db.execute(count_stmt)
    total = total_result.scalar()
    
    # Apply pagination
    stmt = stmt.offset(skip).limit(limit)
    result = await db.execute(stmt)
    users = result.scalars().all()
    
    return {
        "users": [
            {
                "id": user.id,
                "email": user.email,
                "username": user.username,
                "first_name": user.first_name,
                "last_name": user.last_name,
                "user_type": user.user_type,
                "is_active": user.is_active,
                "created_at": user.created_at,
                "last_login": user.last_login
            }
            for user in users
        ],
        "total": total,
        "skip": skip,
        "limit": limit
    }

@router.get("/{user_id}")
async def get_user(
    user_id: int,
    current_user: User = Depends(get_current_user),
    db: AsyncSession = Depends(get_db)
):
    """Get specific user"""
    
    # Users can only view their own profile unless they're admin
    if current_user.id != user_id and current_user.user_type != "administrator":
        raise HTTPException(
            status_code=status.HTTP_403_FORBIDDEN,
            detail="Not enough permissions"
        )
    
    stmt = select(User).where(User.id == user_id)
    result = await db.execute(stmt)
    user = result.scalar_one_or_none()
    
    if not user:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail="User not found"
        )
    
    return {
        "id": user.id,
        "email": user.email,
        "username": user.username,
        "first_name": user.first_name,
        "last_name": user.last_name,
        "user_type": user.user_type,
        "phone": user.phone,
        "is_active": user.is_active,
        "is_verified": user.is_verified,
        "created_at": user.created_at,
        "last_login": user.last_login,
        "profile_data": user.profile_data,
        "roles": [role.name for role in user.roles]
    }

@router.put("/{user_id}")
async def update_user(
    user_id: int,
    user_update: UserUpdate,
    current_user: User = Depends(get_current_user),
    db: AsyncSession = Depends(get_db)
):
    """Update user"""
    
    # Users can only update their own profile unless they're admin
    if current_user.id != user_id and current_user.user_type != "administrator":
        raise HTTPException(
            status_code=status.HTTP_403_FORBIDDEN,
            detail="Not enough permissions"
        )
    
    stmt = select(User).where(User.id == user_id)
    result = await db.execute(stmt)
    user = result.scalar_one_or_none()
    
    if not user:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail="User not found"
        )
    
    # Update fields
    update_data = user_update.dict(exclude_unset=True)
    for field, value in update_data.items():
        setattr(user, field, value)
    
    user.updated_at = datetime.utcnow()
    
    await db.commit()
    await db.refresh(user)
    
    return {"message": "User updated successfully"}

@router.post("/students")
async def create_student_profile(
    student_data: StudentCreate,
    current_user: User = Depends(get_current_user),
    db: AsyncSession = Depends(get_db)
):
    """Create student profile"""
    
    # Only admin can create student profiles
    if current_user.user_type != "administrator":
        raise HTTPException(
            status_code=status.HTTP_403_FORBIDDEN,
            detail="Not enough permissions"
        )
    
    # Check if user exists and is a student
    stmt = select(User).where(User.id == student_data.user_id)
    result = await db.execute(stmt)
    user = result.scalar_one_or_none()
    
    if not user:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail="User not found"
        )
    
    if user.user_type != "student":
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail="User is not a student"
        )
    
    # Check if student profile already exists
    stmt = select(Student).where(Student.user_id == student_data.user_id)
    result = await db.execute(stmt)
    existing_student = result.scalar_one_or_none()
    
    if existing_student:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail="Student profile already exists"
        )
    
    # Create student profile
    new_student = Student(
        user_id=student_data.user_id,
        student_id=student_data.student_id,
        enrollment_date=student_data.enrollment_date,
        grade_level=student_data.grade_level,
        section=student_data.section,
        academic_year=student_data.academic_year
    )
    
    db.add(new_student)
    await db.commit()
    await db.refresh(new_student)
    
    return {"message": "Student profile created successfully", "student_id": new_student.id}

@router.post("/teachers")
async def create_teacher_profile(
    teacher_data: TeacherCreate,
    current_user: User = Depends(get_current_user),
    db: AsyncSession = Depends(get_db)
):
    """Create teacher profile"""
    
    # Only admin can create teacher profiles
    if current_user.user_type != "administrator":
        raise HTTPException(
            status_code=status.HTTP_403_FORBIDDEN,
            detail="Not enough permissions"
        )
    
    # Check if user exists and is a teacher
    stmt = select(User).where(User.id == teacher_data.user_id)
    result = await db.execute(stmt)
    user = result.scalar_one_or_none()
    
    if not user:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail="User not found"
        )
    
    if user.user_type != "teacher":
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail="User is not a teacher"
        )
    
    # Check if teacher profile already exists
    stmt = select(Teacher).where(Teacher.user_id == teacher_data.user_id)
    result = await db.execute(stmt)
    existing_teacher = result.scalar_one_or_none()
    
    if existing_teacher:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail="Teacher profile already exists"
        )
    
    # Create teacher profile
    new_teacher = Teacher(
        user_id=teacher_data.user_id,
        employee_id=teacher_data.employee_id,
        hire_date=teacher_data.hire_date,
        department=teacher_data.department,
        qualification=teacher_data.qualification,
        subjects=teacher_data.subjects or []
    )
    
    db.add(new_teacher)
    await db.commit()
    await db.refresh(new_teacher)
    
    return {"message": "Teacher profile created successfully", "teacher_id": new_teacher.id}

@router.get("/students/{student_id}/unified-data")
async def get_student_unified_data(
    student_id: str,
    current_user: User = Depends(get_current_user),
    db: AsyncSession = Depends(get_db)
):
    """Get unified student data from all modules"""
    
    # Check permissions
    if current_user.user_type not in ["administrator", "teacher"]:
        # Students can only view their own data
        if current_user.user_type == "student":
            stmt = select(Student).where(Student.user_id == current_user.id)
            result = await db.execute(stmt)
            student = result.scalar_one_or_none()
            
            if not student or student.student_id != student_id:
                raise HTTPException(
                    status_code=status.HTTP_403_FORBIDDEN,
                    detail="Not enough permissions"
                )
        else:
            raise HTTPException(
                status_code=status.HTTP_403_FORBIDDEN,
                detail="Not enough permissions"
            )
    
    # Find student
    stmt = select(Student).where(Student.student_id == student_id)
    result = await db.execute(stmt)
    student = result.scalar_one_or_none()
    
    if not student:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail="Student not found"
        )
    
    # Get user info
    stmt = select(User).where(User.id == student.user_id)
    result = await db.execute(stmt)
    user = result.scalar_one_or_none()
    
    # This would normally call the MCP hub to get data from all modules
    # For now, return structured placeholder data
    unified_data = {
        "student_info": {
            "id": student.student_id,
            "name": f"{user.first_name} {user.last_name}",
            "email": user.email,
            "grade_level": student.grade_level,
            "section": student.section,
            "enrollment_date": student.enrollment_date,
            "status": student.status
        },
        "attendance": {
            "total_days": 180,
            "present_days": 165,
            "absent_days": 15,
            "attendance_rate": 91.7,
            "last_updated": datetime.utcnow().isoformat()
        },
        "evaluations": {
            "current_gpa": 3.8,
            "total_assessments": 25,
            "completed_assessments": 23,
            "pending_assessments": 2,
            "competency_progress": {},
            "last_updated": datetime.utcnow().isoformat()
        },
        "communications": {
            "unread_messages": 3,
            "recent_announcements": [],
            "parent_notifications": [],
            "last_updated": datetime.utcnow().isoformat()
        },
        "payments": {
            "total_fees": 5000.00,
            "paid_amount": 3500.00,
            "pending_amount": 1500.00,
            "last_payment_date": None,
            "last_updated": datetime.utcnow().isoformat()
        }
    }
    
    return unified_data
