
"""
Module management routes for Educational Hub MCP
"""
from fastapi import APIRouter, Depends, HTTPException, status
from fastapi.security import HTTPBearer
from sqlalchemy.ext.asyncio import AsyncSession
from sqlalchemy import select
from pydantic import BaseModel
from typing import List, Dict, Any, Optional
from datetime import datetime

from database.connection import get_db
from database.models import User, Module, ModuleConnection
from auth.jwt_handler import JWTHandler

router = APIRouter()
security = HTTPBearer()
jwt_handler = JWTHandler()

class ModuleCreate(BaseModel):
    name: str
    display_name: str
    description: Optional[str] = None
    module_type: str
    version: str
    base_url: Optional[str] = None
    mcp_endpoint: Optional[str] = None
    capabilities: List[str] = []
    config: Dict[str, Any] = {}

class ModuleUpdate(BaseModel):
    display_name: Optional[str] = None
    description: Optional[str] = None
    base_url: Optional[str] = None
    mcp_endpoint: Optional[str] = None
    capabilities: Optional[List[str]] = None
    config: Optional[Dict[str, Any]] = None
    is_active: Optional[bool] = None

async def get_current_user(
    token: str = Depends(security),
    db: AsyncSession = Depends(get_db)
):
    """Get current user from token"""
    user_info = jwt_handler.get_user_from_token(token.credentials)
    user_id = int(user_info["user_id"])
    
    stmt = select(User).where(User.id == user_id)
    result = await db.execute(stmt)
    user = result.scalar_one_or_none()
    
    if not user:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail="User not found"
        )
    
    return user

def check_admin_permissions(user: User):
    """Check if user has admin permissions"""
    if user.user_type != "administrator":
        raise HTTPException(
            status_code=status.HTTP_403_FORBIDDEN,
            detail="Administrator permissions required"
        )

@router.get("/")
async def get_modules(
    current_user: User = Depends(get_current_user),
    db: AsyncSession = Depends(get_db)
):
    """Get all registered modules"""
    
    stmt = select(Module)
    result = await db.execute(stmt)
    modules = result.scalars().all()
    
    return {
        "modules": [
            {
                "id": module.id,
                "name": module.name,
                "display_name": module.display_name,
                "description": module.description,
                "module_type": module.module_type,
                "version": module.version,
                "is_active": module.is_active,
                "is_connected": module.is_connected,
                "capabilities": module.capabilities,
                "last_ping": module.last_ping,
                "created_at": module.created_at
            }
            for module in modules
        ]
    }

@router.post("/")
async def create_module(
    module_data: ModuleCreate,
    current_user: User = Depends(get_current_user),
    db: AsyncSession = Depends(get_db)
):
    """Create new module registration"""
    
    check_admin_permissions(current_user)
    
    # Check if module already exists
    stmt = select(Module).where(Module.name == module_data.name)
    result = await db.execute(stmt)
    existing_module = result.scalar_one_or_none()
    
    if existing_module:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail="Module with this name already exists"
        )
    
    # Create new module
    new_module = Module(
        name=module_data.name,
        display_name=module_data.display_name,
        description=module_data.description,
        module_type=module_data.module_type,
        version=module_data.version,
        base_url=module_data.base_url,
        mcp_endpoint=module_data.mcp_endpoint,
        capabilities=module_data.capabilities,
        config=module_data.config
    )
    
    db.add(new_module)
    await db.commit()
    await db.refresh(new_module)
    
    return {
        "message": "Module created successfully",
        "module_id": new_module.id
    }

@router.get("/{module_id}")
async def get_module(
    module_id: int,
    current_user: User = Depends(get_current_user),
    db: AsyncSession = Depends(get_db)
):
    """Get specific module details"""
    
    stmt = select(Module).where(Module.id == module_id)
    result = await db.execute(stmt)
    module = result.scalar_one_or_none()
    
    if not module:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail="Module not found"
        )
    
    # Get module connections
    stmt = select(ModuleConnection).where(ModuleConnection.module_id == module_id)
    result = await db.execute(stmt)
    connections = result.scalars().all()
    
    return {
        "id": module.id,
        "name": module.name,
        "display_name": module.display_name,
        "description": module.description,
        "module_type": module.module_type,
        "version": module.version,
        "base_url": module.base_url,
        "mcp_endpoint": module.mcp_endpoint,
        "config": module.config,
        "capabilities": module.capabilities,
        "is_active": module.is_active,
        "is_connected": module.is_connected,
        "last_ping": module.last_ping,
        "created_at": module.created_at,
        "updated_at": module.updated_at,
        "connections": [
            {
                "id": conn.id,
                "connection_type": conn.connection_type,
                "endpoint": conn.endpoint,
                "status": conn.status,
                "last_sync": conn.last_sync,
                "sync_status": conn.sync_status,
                "error_count": conn.error_count,
                "last_error": conn.last_error
            }
            for conn in connections
        ]
    }

@router.put("/{module_id}")
async def update_module(
    module_id: int,
    module_update: ModuleUpdate,
    current_user: User = Depends(get_current_user),
    db: AsyncSession = Depends(get_db)
):
    """Update module"""
    
    check_admin_permissions(current_user)
    
    stmt = select(Module).where(Module.id == module_id)
    result = await db.execute(stmt)
    module = result.scalar_one_or_none()
    
    if not module:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail="Module not found"
        )
    
    # Update fields
    update_data = module_update.dict(exclude_unset=True)
    for field, value in update_data.items():
        setattr(module, field, value)
    
    module.updated_at = datetime.utcnow()
    
    await db.commit()
    await db.refresh(module)
    
    return {"message": "Module updated successfully"}

@router.post("/{module_id}/test-connection")
async def test_module_connection(
    module_id: int,
    current_user: User = Depends(get_current_user),
    db: AsyncSession = Depends(get_db)
):
    """Test connection to module"""
    
    check_admin_permissions(current_user)
    
    stmt = select(Module).where(Module.id == module_id)
    result = await db.execute(stmt)
    module = result.scalar_one_or_none()
    
    if not module:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail="Module not found"
        )
    
    # Here you would implement actual connection testing
    # For now, simulate a connection test
    
    connection_successful = True  # Simulate success
    
    if connection_successful:
        module.is_connected = True
        module.last_ping = datetime.utcnow()
        
        await db.commit()
        
        return {
            "success": True,
            "message": "Connection test successful",
            "timestamp": datetime.utcnow().isoformat()
        }
    else:
        module.is_connected = False
        await db.commit()
        
        return {
            "success": False,
            "message": "Connection test failed",
            "timestamp": datetime.utcnow().isoformat()
        }

@router.post("/{module_id}/sync")
async def sync_module_data(
    module_id: int,
    current_user: User = Depends(get_current_user),
    db: AsyncSession = Depends(get_db)
):
    """Trigger data sync for module"""
    
    check_admin_permissions(current_user)
    
    stmt = select(Module).where(Module.id == module_id)
    result = await db.execute(stmt)
    module = result.scalar_one_or_none()
    
    if not module:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail="Module not found"
        )
    
    if not module.is_connected:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail="Module is not connected"
        )
    
    # Here you would implement actual data sync logic
    # This would typically involve calling the MCP hub
    
    # Create or update sync connection record
    stmt = select(ModuleConnection).where(
        (ModuleConnection.module_id == module_id) &
        (ModuleConnection.connection_type == "mcp")
    )
    result = await db.execute(stmt)
    connection = result.scalar_one_or_none()
    
    if not connection:
        connection = ModuleConnection(
            module_id=module_id,
            connection_type="mcp",
            endpoint=module.mcp_endpoint or "",
            status="connected"
        )
        db.add(connection)
    
    connection.last_sync = datetime.utcnow()
    connection.sync_status = "success"  # Simulate success
    
    await db.commit()
    
    return {
        "message": "Data sync completed successfully",
        "sync_timestamp": connection.last_sync.isoformat()
    }

@router.get("/types/available")
async def get_available_module_types(
    current_user: User = Depends(get_current_user)
):
    """Get available module types"""
    
    return {
        "module_types": [
            {
                "type": "attendance",
                "display_name": "Attendance Management",
                "description": "Track student attendance and tardiness"
            },
            {
                "type": "evaluation",
                "display_name": "Competency Evaluation",
                "description": "Assess student competencies and progress"
            },
            {
                "type": "communication",
                "display_name": "Communication & Notifications",
                "description": "Send messages and notifications to students/parents"
            },
            {
                "type": "payment",
                "display_name": "Payment Management",
                "description": "Handle tuition and fee payments"
            },
            {
                "type": "lms",
                "display_name": "Learning Management System",
                "description": "Course content and assignment management"
            },
            {
                "type": "gradebook",
                "display_name": "Grade Book",
                "description": "Grade recording and reporting"
            }
        ]
    }
