
"""
Reporting routes for Educational Hub MCP
"""
from fastapi import APIRouter, Depends, HTTPException, status, Query
from fastapi.security import HTTPBearer
from sqlalchemy.ext.asyncio import AsyncSession
from sqlalchemy import select, func
from pydantic import BaseModel
from typing import Optional, List, Dict, Any
from datetime import datetime, date, timedelta

from database.connection import get_db
from database.models import User, Student, Teacher, Module
from auth.jwt_handler import JWTHandler

router = APIRouter()
security = HTTPBearer()
jwt_handler = JWTHandler()

class ReportRequest(BaseModel):
    report_type: str
    filters: Dict[str, Any] = {}
    date_range: Optional[Dict[str, str]] = None
    format: str = "json"

async def get_current_user(
    token: str = Depends(security),
    db: AsyncSession = Depends(get_db)
):
    """Get current user from token"""
    user_info = jwt_handler.get_user_from_token(token.credentials)
    user_id = int(user_info["user_id"])
    
    stmt = select(User).where(User.id == user_id)
    result = await db.execute(stmt)
    user = result.scalar_one_or_none()
    
    if not user:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail="User not found"
        )
    
    return user

@router.get("/dashboard")
async def get_dashboard_data(
    current_user: User = Depends(get_current_user),
    db: AsyncSession = Depends(get_db)
):
    """Get dashboard data based on user role"""
    
    if current_user.user_type == "administrator":
        return await get_admin_dashboard(db)
    elif current_user.user_type == "teacher":
        return await get_teacher_dashboard(current_user, db)
    elif current_user.user_type == "student":
        return await get_student_dashboard(current_user, db)
    else:
        raise HTTPException(
            status_code=status.HTTP_403_FORBIDDEN,
            detail="Invalid user type"
        )

async def get_admin_dashboard(db: AsyncSession):
    """Get administrator dashboard data"""
    
    # Get user statistics
    total_users_stmt = select(func.count(User.id))
    total_users_result = await db.execute(total_users_stmt)
    total_users = total_users_result.scalar()
    
    students_stmt = select(func.count(User.id)).where(User.user_type == "student")
    students_result = await db.execute(students_stmt)
    total_students = students_result.scalar()
    
    teachers_stmt = select(func.count(User.id)).where(User.user_type == "teacher")
    teachers_result = await db.execute(teachers_stmt)
    total_teachers = teachers_result.scalar()
    
    # Get module statistics
    modules_stmt = select(func.count(Module.id))
    modules_result = await db.execute(modules_stmt)
    total_modules = modules_result.scalar()
    
    active_modules_stmt = select(func.count(Module.id)).where(Module.is_active == True)
    active_modules_result = await db.execute(active_modules_stmt)
    active_modules = active_modules_result.scalar()
    
    connected_modules_stmt = select(func.count(Module.id)).where(Module.is_connected == True)
    connected_modules_result = await db.execute(connected_modules_stmt)
    connected_modules = connected_modules_result.scalar()
    
    # Get recent activity (simulated)
    recent_activity = [
        {
            "type": "user_registration",
            "message": "New student registered",
            "timestamp": (datetime.utcnow() - timedelta(hours=2)).isoformat(),
            "user": "john.doe@school.edu"
        },
        {
            "type": "module_sync",
            "message": "Attendance module sync completed",
            "timestamp": (datetime.utcnow() - timedelta(hours=4)).isoformat(),
            "module": "attendance"
        },
        {
            "type": "system_alert",
            "message": "High server load detected",
            "timestamp": (datetime.utcnow() - timedelta(hours=6)).isoformat(),
            "severity": "warning"
        }
    ]
    
    return {
        "user_statistics": {
            "total_users": total_users,
            "total_students": total_students,
            "total_teachers": total_teachers,
            "administrators": total_users - total_students - total_teachers
        },
        "module_statistics": {
            "total_modules": total_modules,
            "active_modules": active_modules,
            "connected_modules": connected_modules,
            "connection_rate": (connected_modules / total_modules * 100) if total_modules > 0 else 0
        },
        "system_health": {
            "status": "healthy",
            "uptime": "99.9%",
            "last_backup": (datetime.utcnow() - timedelta(hours=12)).isoformat(),
            "active_sessions": 45
        },
        "recent_activity": recent_activity
    }

async def get_teacher_dashboard(user: User, db: AsyncSession):
    """Get teacher dashboard data"""
    
    # Get teacher profile
    stmt = select(Teacher).where(Teacher.user_id == user.id)
    result = await db.execute(stmt)
    teacher = result.scalar_one_or_none()
    
    if not teacher:
        return {"error": "Teacher profile not found"}
    
    # Simulated teacher data
    return {
        "teacher_info": {
            "employee_id": teacher.employee_id,
            "department": teacher.department,
            "subjects": teacher.subjects
        },
        "classes": {
            "total_classes": 5,
            "active_students": 120,
            "pending_evaluations": 15,
            "recent_attendance": 95.2
        },
        "upcoming_tasks": [
            {
                "type": "evaluation",
                "title": "Math Competency Assessment",
                "due_date": (datetime.utcnow() + timedelta(days=2)).isoformat(),
                "students_count": 25
            },
            {
                "type": "meeting",
                "title": "Parent-Teacher Conference",
                "due_date": (datetime.utcnow() + timedelta(days=5)).isoformat(),
                "location": "Room 101"
            }
        ],
        "recent_activity": [
            {
                "type": "grade_submitted",
                "message": "Submitted grades for Science Quiz",
                "timestamp": (datetime.utcnow() - timedelta(hours=1)).isoformat()
            },
            {
                "type": "attendance_taken",
                "message": "Attendance recorded for Class 10A",
                "timestamp": (datetime.utcnow() - timedelta(hours=3)).isoformat()
            }
        ]
    }

async def get_student_dashboard(user: User, db: AsyncSession):
    """Get student dashboard data"""
    
    # Get student profile
    stmt = select(Student).where(Student.user_id == user.id)
    result = await db.execute(stmt)
    student = result.scalar_one_or_none()
    
    if not student:
        return {"error": "Student profile not found"}
    
    # Simulated student data
    return {
        "student_info": {
            "student_id": student.student_id,
            "grade_level": student.grade_level,
            "section": student.section,
            "academic_year": student.academic_year
        },
        "academic_summary": {
            "current_gpa": 3.8,
            "attendance_rate": 95.5,
            "completed_assignments": 28,
            "pending_assignments": 3
        },
        "upcoming_events": [
            {
                "type": "exam",
                "title": "Mathematics Final Exam",
                "date": (datetime.utcnow() + timedelta(days=7)).isoformat(),
                "location": "Room 201"
            },
            {
                "type": "project",
                "title": "Science Project Submission",
                "date": (datetime.utcnow() + timedelta(days=14)).isoformat(),
                "subject": "Physics"
            }
        ],
        "recent_grades": [
            {
                "subject": "Mathematics",
                "assignment": "Algebra Quiz",
                "grade": "A",
                "date": (datetime.utcnow() - timedelta(days=2)).isoformat()
            },
            {
                "subject": "Science",
                "assignment": "Lab Report",
                "grade": "B+",
                "date": (datetime.utcnow() - timedelta(days=5)).isoformat()
            }
        ]
    }

@router.post("/generate")
async def generate_report(
    report_request: ReportRequest,
    current_user: User = Depends(get_current_user),
    db: AsyncSession = Depends(get_db)
):
    """Generate custom report"""
    
    # Check permissions
    if current_user.user_type not in ["administrator", "teacher"]:
        raise HTTPException(
            status_code=status.HTTP_403_FORBIDDEN,
            detail="Not enough permissions"
        )
    
    report_type = report_request.report_type
    
    if report_type == "attendance_summary":
        return await generate_attendance_report(report_request, db)
    elif report_type == "evaluation_summary":
        return await generate_evaluation_report(report_request, db)
    elif report_type == "student_progress":
        return await generate_student_progress_report(report_request, db)
    elif report_type == "module_status":
        return await generate_module_status_report(report_request, db)
    else:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail="Invalid report type"
        )

async def generate_attendance_report(request: ReportRequest, db: AsyncSession):
    """Generate attendance summary report"""
    
    # This would normally query the attendance module via MCP
    # For now, return simulated data
    
    return {
        "report_type": "attendance_summary",
        "generated_at": datetime.utcnow().isoformat(),
        "date_range": request.date_range,
        "summary": {
            "total_students": 150,
            "average_attendance": 94.2,
            "perfect_attendance": 25,
            "chronic_absenteeism": 8
        },
        "by_grade": [
            {"grade": "9", "attendance_rate": 95.1, "students": 40},
            {"grade": "10", "attendance_rate": 93.8, "students": 38},
            {"grade": "11", "attendance_rate": 94.5, "students": 35},
            {"grade": "12", "attendance_rate": 93.2, "students": 37}
        ],
        "trends": {
            "daily_average": 94.2,
            "weekly_trend": "stable",
            "monthly_comparison": "+2.1%"
        }
    }

async def generate_evaluation_report(request: ReportRequest, db: AsyncSession):
    """Generate evaluation summary report"""
    
    return {
        "report_type": "evaluation_summary",
        "generated_at": datetime.utcnow().isoformat(),
        "date_range": request.date_range,
        "summary": {
            "total_evaluations": 450,
            "completed_evaluations": 425,
            "average_score": 78.5,
            "competency_mastery_rate": 82.3
        },
        "by_subject": [
            {"subject": "Mathematics", "avg_score": 75.2, "evaluations": 120},
            {"subject": "Science", "avg_score": 81.8, "evaluations": 110},
            {"subject": "English", "avg_score": 79.1, "evaluations": 100},
            {"subject": "History", "avg_score": 77.9, "evaluations": 95}
        ],
        "competency_breakdown": {
            "mastered": 68,
            "developing": 25,
            "beginning": 7
        }
    }

async def generate_student_progress_report(request: ReportRequest, db: AsyncSession):
    """Generate student progress report"""
    
    return {
        "report_type": "student_progress",
        "generated_at": datetime.utcnow().isoformat(),
        "summary": {
            "students_analyzed": 150,
            "above_grade_level": 45,
            "at_grade_level": 85,
            "below_grade_level": 20
        },
        "progress_indicators": {
            "attendance_correlation": 0.72,
            "assignment_completion": 89.5,
            "parent_engagement": 76.3
        },
        "interventions_needed": 12,
        "success_stories": 8
    }

async def generate_module_status_report(request: ReportRequest, db: AsyncSession):
    """Generate module status report"""
    
    stmt = select(Module)
    result = await db.execute(stmt)
    modules = result.scalars().all()
    
    module_data = []
    for module in modules:
        module_data.append({
            "name": module.name,
            "type": module.module_type,
            "status": "connected" if module.is_connected else "disconnected",
            "last_sync": module.last_ping.isoformat() if module.last_ping else None,
            "version": module.version,
            "health_score": 95 if module.is_connected else 0  # Simulated
        })
    
    return {
        "report_type": "module_status",
        "generated_at": datetime.utcnow().isoformat(),
        "modules": module_data,
        "summary": {
            "total_modules": len(modules),
            "connected_modules": sum(1 for m in modules if m.is_connected),
            "average_health": sum(95 if m.is_connected else 0 for m in modules) / len(modules) if modules else 0,
            "critical_issues": 0,
            "warnings": 1
        }
    }

@router.get("/types")
async def get_available_report_types(
    current_user: User = Depends(get_current_user)
):
    """Get available report types"""
    
    base_reports = [
        {
            "type": "attendance_summary",
            "name": "Attendance Summary",
            "description": "Overall attendance statistics and trends"
        },
        {
            "type": "evaluation_summary",
            "name": "Evaluation Summary",
            "description": "Competency evaluation results and analysis"
        },
        {
            "type": "student_progress",
            "name": "Student Progress",
            "description": "Individual student progress tracking"
        }
    ]
    
    if current_user.user_type == "administrator":
        base_reports.append({
            "type": "module_status",
            "name": "Module Status",
            "description": "System module health and connectivity status"
        })
    
    return {"report_types": base_reports}
