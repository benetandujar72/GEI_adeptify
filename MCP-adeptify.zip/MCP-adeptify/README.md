
# Educational Hub MCP

Central hub for modular educational system using MCP (Model Context Protocol) architecture.

## Overview

The Educational Hub MCP serves as the central coordination point for a modular educational system. It provides:

- **Centralized Authentication**: JWT-based authentication system
- **Module Coordination**: MCP server for inter-module communication
- **Unified Data Access**: Single API for accessing data across all educational modules
- **Role-based Permissions**: Granular access control for students, teachers, and administrators
- **Real-time Notifications**: Cross-module notification system
- **Comprehensive Reporting**: Consolidated reports from all modules

## Architecture

```
Educational Hub MCP
├── FastAPI REST API (Port 5000)
├── FastMCP Server (Port 8765)
├── PostgreSQL Database
├── JWT Authentication
└── Module Connectors
    ├── Attendance Module
    ├── Evaluation Module
    ├── Communication Module
    └── Future Modules
```

## Quick Start

### 1. Environment Setup

```bash
# Copy environment template
cp .env.example .env

# Edit .env with your configuration
# Especially important: DATABASE_URL and JWT_SECRET_KEY
```

### 2. Database Setup

```bash
# Install PostgreSQL and create database
createdb educational_hub

# Update DATABASE_URL in .env file
DATABASE_URL=postgresql://username:password@localhost:5432/educational_hub
```

### 3. Install Dependencies

```bash
pip install -r requirements.txt
```

### 4. Run the Application

```bash
# Development mode
python main.py

# Or with uvicorn directly
uvicorn main:app --host 0.0.0.0 --port 5000 --reload
```

The application will be available at:
- REST API: http://localhost:5000
- API Documentation: http://localhost:5000/docs
- Health Check: http://localhost:5000/health

## API Endpoints

### Authentication
- `POST /api/auth/register` - Register new user
- `POST /api/auth/login` - User login
- `GET /api/auth/me` - Get current user info
- `POST /api/auth/refresh` - Refresh access token

### User Management
- `GET /api/users/` - List users (admin only)
- `GET /api/users/{user_id}` - Get user details
- `PUT /api/users/{user_id}` - Update user
- `POST /api/users/students` - Create student profile
- `POST /api/users/teachers` - Create teacher profile
- `GET /api/users/students/{student_id}/unified-data` - Get unified student data

### Module Management
- `GET /api/modules/` - List registered modules
- `POST /api/modules/` - Register new module (admin only)
- `GET /api/modules/{module_id}` - Get module details
- `PUT /api/modules/{module_id}` - Update module (admin only)
- `POST /api/modules/{module_id}/test-connection` - Test module connection
- `POST /api/modules/{module_id}/sync` - Trigger data sync

### Reporting
- `GET /api/reports/dashboard` - Get role-based dashboard data
- `POST /api/reports/generate` - Generate custom reports
- `GET /api/reports/types` - Get available report types

## MCP Tools

The FastMCP server provides these tools for module communication:

### `register_module`
Register a new educational module with the hub.

**Parameters:**
- `name`: Module identifier
- `module_type`: Type of module (attendance, evaluation, etc.)
- `version`: Module version
- `endpoints`: List of available endpoints
- `capabilities`: List of module capabilities

### `send_module_message`
Send messages between modules.

**Parameters:**
- `source_module`: Sending module name
- `target_module`: Receiving module name
- `message_type`: Type of message
- `payload`: Message data

### `get_student_unified_data`
Get consolidated student data from all modules.

**Parameters:**
- `student_id`: Student identifier

### `broadcast_notification`
Send notifications to multiple modules.

**Parameters:**
- `message_type`: Notification type
- `content`: Notification content
- `target_modules`: List of target modules (optional)

### `get_module_status`
Get status of all registered modules.

## User Roles and Permissions

### Student
- View own profile and academic data
- Access personal dashboard
- View own attendance, grades, and assignments

### Teacher
- View assigned students' data
- Access teacher dashboard
- Create and grade evaluations
- Take attendance for assigned classes

### Administrator
- Full system access
- User management
- Module management
- System reports and analytics
- Configure system settings

## Module Integration

### Registering a New Module

1. **Register via API:**
```bash
curl -X POST "http://localhost:5000/api/modules/" \
  -H "Authorization: Bearer YOUR_JWT_TOKEN" \
  -H "Content-Type: application/json" \
  -d '{
    "name": "my_module",
    "display_name": "My Educational Module",
    "module_type": "custom",
    "version": "1.0.0",
    "mcp_endpoint": "http://localhost:5004/mcp",
    "capabilities": ["data_sync", "notifications"]
  }'
```

2. **Connect via MCP:**
```python
# In your module
from fastmcp import FastMCP

# Register with hub
hub_client.call_tool("register_module", {
    "name": "my_module",
    "module_type": "custom",
    "version": "1.0.0",
    "endpoints": ["/api/data", "/api/sync"],
    "capabilities": ["data_sync", "notifications"]
})
```

### Sending Data Between Modules

```python
# Send message to another module
hub_client.call_tool("send_module_message", {
    "source_module": "attendance",
    "target_module": "evaluation",
    "message_type": "student_absent",
    "payload": {
        "student_id": "STU001",
        "date": "2024-01-15",
        "reason": "sick"
    }
})
```

## Database Schema

### Core Tables
- `users` - All system users (students, teachers, administrators)
- `roles` - User roles
- `permissions` - Granular permissions
- `students` - Extended student information
- `teachers` - Extended teacher information
- `modules` - Registered modules
- `module_connections` - Module connection status

### Relationships
- Users have many roles (many-to-many)
- Roles have many permissions (many-to-many)
- Students/Teachers link to users (one-to-one)
- Modules have many connections (one-to-many)

## Security Features

### Authentication
- JWT access tokens (30 minutes)
- JWT refresh tokens (7 days)
- Bcrypt password hashing
- Token-based API access

### Authorization
- Role-based access control (RBAC)
- Granular permissions system
- Resource-level access control
- Module-specific permissions

### Data Protection
- SQL injection prevention (SQLAlchemy ORM)
- Input validation (Pydantic)
- CORS protection
- Environment-based configuration

## Monitoring and Logging

### Health Checks
- `/health` endpoint for system status
- Database connection monitoring
- Module connectivity tracking
- MCP hub status monitoring

### Logging
- Structured logging with timestamps
- Request/response logging
- Error tracking
- Module communication logs

## Production Deployment

### Environment Variables
Ensure these are set in production:
```bash
DEBUG=false
JWT_SECRET_KEY=your-secure-production-key
DATABASE_URL=postgresql://user:pass@db:5432/educational_hub
LOG_LEVEL=INFO
```

### Database Migration
```bash
# Run migrations (if using Alembic)
alembic upgrade head
```

### Performance Considerations
- Use connection pooling for database
- Implement Redis caching for frequently accessed data
- Monitor API response times
- Scale modules independently

## Contributing

### Development Setup
1. Fork the repository
2. Create feature branch
3. Install development dependencies
4. Run tests
5. Submit pull request

### Code Style
- Use Black for code formatting
- Follow PEP 8 guidelines
- Add type hints
- Write comprehensive tests

## Troubleshooting

### Common Issues

**Database Connection Error:**
- Check DATABASE_URL in .env
- Ensure PostgreSQL is running
- Verify database exists

**JWT Token Issues:**
- Check JWT_SECRET_KEY configuration
- Verify token expiration settings
- Check token format in requests

**Module Connection Problems:**
- Verify module endpoints are accessible
- Check MCP server status
- Review module registration

### Support
For issues and questions:
1. Check the logs for error details
2. Verify configuration settings
3. Test individual components
4. Review API documentation

## License

This project is licensed under the MIT License.
